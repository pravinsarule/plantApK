// dule.exports = router;

// const express = require('express');
// const router = express.Router();

// const cityController = require('../controllers/vendorCitiesController'); // adjust the path as needed

// // Assign city to vendor (create city if needed)
// router.post('/assign', cityController.assignCityToVendor);

// // Get all cities assigned to a vendor
// router.get('/user/:vendor_id', cityController.getVendorCities);

// // Get all cities
// router.get('/', cityController.getAllCities);

// // Update city by ID
// router.put('/update/:id', cityController.updateCity);

// // Delete vendor city by ID
// // router.delete('/delete:id', cityController.removeCityFromVendor);
// router.delete('/delete/:vendor_id/:city_id', cityController.removeCityFromVendor);



// module.exports = router;
